﻿var pageIndex = -1;
var doGetImage = true;

$(document).ready(function () {

    GenerateGallery();
});

function GenerateGallery() {
    GetImages();
}

$(window).scroll(function () {

    if (!($(window).scrollTop() + $(window).height() == $(document).height())) {

        GetImages();
    }
});



function GetImages() {

    pageIndex++;
    if (doGetImage == true) {
        $.ajax({
            type: "POST",
            url: "../Gallery/GetImages",
            data: '{pageIndex: ' + pageIndex + '}',
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: OnSuccess,
            failure: function (response) {
                alert("Something went wrong");
            }
        });
    }


}

function GenerateHtml(imgsrc) {

    var html = '<div class="box"><img src="' + imgsrc + '"><h2>Title Goes Here</h2><p>Description...</p></div>';

    $('#imgDiv').append(html);
}


function OnSuccess(response) {

    if (response.ImageList.length > 0) {

        $.each(response.ImageList, function () {

            var newStringParam = removeCharecter($(this)[0].Path, '~');
            GenerateHtml(newStringParam);

        });
    }

}

function removeCharecter(stringParam, charParam) {

    if (stringParam != undefined)
        return stringParam.replace(charParam, '');
}