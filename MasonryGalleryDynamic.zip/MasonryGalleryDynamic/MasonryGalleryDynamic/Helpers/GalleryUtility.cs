﻿using MasonryGalleryDynamic.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;

namespace MasonryGalleryDynamic.Helpers
{
    public class GalleryUtility
    {
        public static GalleryModel GetImagesFromRoot(int prefereAmount, int pageIndex, string root)
        {
            var gallerimodel = new Models.GalleryModel();
            gallerimodel.ImageList = new List<ImageListModel>();

            var skipAmount = pageIndex * prefereAmount;

            var list = Directory.EnumerateFiles(HttpContext.Current.Server.MapPath(Models.ConstantParameters.ImagePath))
               .Select(fn => Models.ConstantParameters.ImagePath + "/" + Path.GetFileName(fn)).OrderBy(fn =>
               Models.ConstantParameters.ImagePath + "/" + Path.GetFileName(fn)).Skip(skipAmount).Take(prefereAmount)
               .ToList();

            if (list.Count > 0)
            {
                foreach (var item in list)
                {
                    var imageList = new Models.ImageListModel();

                    imageList.Path = item;

                    gallerimodel.ImageList.Add(imageList);
                }

            }

            return gallerimodel;
        }

    }
}