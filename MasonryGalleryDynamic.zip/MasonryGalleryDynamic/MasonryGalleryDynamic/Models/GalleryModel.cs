﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MasonryGalleryDynamic.Models
{
    public class GalleryModel
    {
        public List<ImageListModel> ImageList;
    }
}