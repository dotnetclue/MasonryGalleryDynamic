﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MasonryGalleryDynamic.Controllers
{
    public class GalleryController : Controller
    {
        // GET: Gallery
        public ActionResult Index()
        {
            return View();
        }

        public JsonResult GetImages(int pageIndex)
        {
            string root = Server.MapPath(Models.ConstantParameters.ImagePath);

            var result = Helpers.GalleryUtility.GetImagesFromRoot(Models.ConstantParameters.PreferAmount, pageIndex, root);

            return Json(result, JsonRequestBehavior.AllowGet);

        }
    }
}